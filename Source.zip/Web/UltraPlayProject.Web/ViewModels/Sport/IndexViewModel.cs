﻿namespace UltraPlayProject.Web.ViewModels.Sport
{
    using System.Collections.Generic;

    public class IndexViewModel
    {
        public IEnumerable<SportViewModel> Sports { get; set; }
    }
}
