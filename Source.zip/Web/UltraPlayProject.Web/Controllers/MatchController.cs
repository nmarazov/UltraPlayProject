﻿namespace UltraPlayProject.Web.Controllers
{
    using System.Web.Mvc;

    public class MatchController : Controller
    {
        // GET: Match
        public ActionResult Index()
        {
            return this.View();
        }
    }
}
