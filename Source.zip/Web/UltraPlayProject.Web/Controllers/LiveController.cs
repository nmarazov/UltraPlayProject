﻿using System.Web.Mvc;

namespace UltraPlayProject.Web.Controllers
{
    public class LiveController : Controller
    {
        public ActionResult LiveEvents()
        {
            throw new System.NotImplementedException();
        }
    }
}
