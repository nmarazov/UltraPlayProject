﻿namespace UltraPlayProject.Web.Infrastructure.Mapping
{
    public interface IMapFrom<T>
        where T : class
    {
    }
}
